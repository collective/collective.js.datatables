from Products.Five import BrowserView

class Example(BrowserView):
    """Simple Example View example"""
